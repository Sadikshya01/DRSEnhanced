/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package database;

import model.EmergencyShelter;
import java.util.List;

public class TestEmergencyShelterDAO {

    public static void main(String[] args) {

        try {
            EmergencyShelterDAO dao = new EmergencyShelterDAO();

            EmergencyShelter shelter = new EmergencyShelter(
                    0,
                    "Assessment Test Shelter",
                    "Sydney",
                    100,
                    25,
                    "Available",
                    "0400000000"
            );

            // Save the shelter
            dao.save(shelter);

            System.out.println("Shelter saved successfully.");
            System.out.println(
                    "Generated shelter ID: " + shelter.getShelterId());

            // Retrieve all shelters
            List<EmergencyShelter> shelters = dao.findAll();

            System.out.println(
                    "Total shelters retrieved: " + shelters.size());

            for (EmergencyShelter savedShelter : shelters) {
                System.out.println(
                        savedShelter.getShelterId() + " - "
                        + savedShelter.getShelterName() + " - "
                        + savedShelter.getLocation() + " - "
                        + savedShelter.getOccupants() + "/"
                        + savedShelter.getCapacity() + " occupants");
            }

        } catch (Exception e) {
            System.err.println("Shelter DAO test failed.");
            e.printStackTrace();
        }
    }
}
