/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

/**
 *
 * @author Keerthi
 */
import model.DisasterReport;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
public class DisasterReportDAO {
    // Save a disaster report and let MySQL generate its ID.
    public DisasterReport save(DisasterReport report)
            throws SQLException {

        String sql = """
            INSERT INTO disaster_reports
            (disaster_type, location, report_datetime, description,
             severity, people_affected, infrastructure_impact,
             priority, status, assigned_department)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     sql, Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, report.getDisasterType());
            statement.setString(2, report.getLocation());

            LocalDateTime dateTime = report.getDateTime();
            if (dateTime == null) {
                dateTime = LocalDateTime.now();
                report.setDateTime(dateTime);
            }
            statement.setTimestamp(3, Timestamp.valueOf(dateTime));
            statement.setString(4, report.getDescription());
            statement.setInt(5, report.getSeverity());
            statement.setInt(6, report.getPeopleAffected());
            statement.setString(7, report.getInfrastructureImpact());
            statement.setString(8, report.getPriority());
            statement.setString(9, report.getStatus());
            statement.setString(10, report.getAssignedDepartment());

            int rowsInserted = statement.executeUpdate();

            if (rowsInserted == 0) {
                throw new SQLException("Saving the report failed.");
            }
            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) {
                    report.setDisasterId(keys.getInt(1));
                } else {
                    throw new SQLException(
                            "MySQL did not return the generated report ID.");
                }
            }
        }
        return report;
    }
    // Retrieve all reports, newest IDs first.
    public List<DisasterReport> findAll() throws SQLException {

        String sql = """
            SELECT disaster_id, disaster_type, location, report_datetime,
                   description, severity, people_affected,
                   infrastructure_impact, priority, status,
                   assigned_department
            FROM disaster_reports
            ORDER BY disaster_id DESC
            """;

        List<DisasterReport> reports = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            while (result.next()) {
                DisasterReport report = new DisasterReport(
                        result.getInt("disaster_id"),
                        result.getString("disaster_type"),
                        result.getString("location"),
                        result.getTimestamp("report_datetime")
                                .toLocalDateTime(),
                        result.getString("description"),
                        result.getInt("severity"),
                        result.getInt("people_affected"),
                        result.getString("infrastructure_impact")
                );

                report.setPriority(result.getString("priority"));
                report.setStatus(result.getString("status"));
                report.setAssignedDepartment(
                        result.getString("assigned_department"));

                reports.add(report);
            }
        }

        return reports;
    }
    // Update priority, response status, and assigned department in MySQL.
    public boolean update(DisasterReport report) throws SQLException {

        String sql = """
            UPDATE disaster_reports
            SET priority = ?, status = ?, assigned_department = ?
            WHERE disaster_id = ?
            """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, report.getPriority());
            statement.setString(2, report.getStatus());
            statement.setString(3, report.getAssignedDepartment());
            statement.setInt(4, report.getDisasterId());

            return statement.executeUpdate() == 1;
        }
    }

    
}
