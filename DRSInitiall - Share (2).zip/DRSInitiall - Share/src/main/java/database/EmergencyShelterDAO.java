/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package database;

import model.EmergencyShelter;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EmergencyShelterDAO {

    // Save a new shelter and retrieve its generated ID.
    public EmergencyShelter save(EmergencyShelter shelter)
            throws SQLException {

        String sql = """
            INSERT INTO emergency_shelters
            (shelter_name, location, capacity, occupants,
             availability, contact_number)
            VALUES (?, ?, ?, ?, ?, ?)
            """;

        validateShelter(shelter);

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(
                     sql, java.sql.Statement.RETURN_GENERATED_KEYS)) {

            statement.setString(1, shelter.getShelterName());
            statement.setString(2, shelter.getLocation());
            statement.setInt(3, shelter.getCapacity());
            statement.setInt(4, shelter.getOccupants());
            statement.setString(5, shelter.getAvailability());
            statement.setString(6, shelter.getContactNumber());

            statement.executeUpdate();

            try (ResultSet keys = statement.getGeneratedKeys()) {
                if (keys.next()) {
                    shelter.setShelterId(keys.getInt(1));
                } else {
                    throw new SQLException(
                            "MySQL did not return a shelter ID.");
                }
            }
        }

        return shelter;
    }

    // Retrieve all shelters.
    public List<EmergencyShelter> findAll() throws SQLException {

        String sql = """
            SELECT shelter_id, shelter_name, location, capacity,
                   occupants, availability, contact_number
            FROM emergency_shelters
            ORDER BY shelter_id DESC
            """;

        List<EmergencyShelter> shelters = new ArrayList<>();

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            while (result.next()) {
                shelters.add(new EmergencyShelter(
                        result.getInt("shelter_id"),
                        result.getString("shelter_name"),
                        result.getString("location"),
                        result.getInt("capacity"),
                        result.getInt("occupants"),
                        result.getString("availability"),
                        result.getString("contact_number")
                ));
            }
        }

        return shelters;
    }

    // Update the number of occupants in an existing shelter.
    public boolean updateOccupants(int shelterId, int occupants)
            throws SQLException {

        String sql = """
            UPDATE emergency_shelters
            SET occupants = ?,
                availability = CASE
                    WHEN ? = capacity THEN 'Full'
                    ELSE 'Available'
                END
            WHERE shelter_id = ?
              AND ? >= 0
              AND ? <= capacity
            """;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, occupants);
            statement.setInt(2, occupants);
            statement.setInt(3, shelterId);
            statement.setInt(4, occupants);
            statement.setInt(5, occupants);

            return statement.executeUpdate() == 1;
        }
    }

    private void validateShelter(EmergencyShelter shelter) {
        if (shelter == null
                || shelter.getShelterName() == null
                || shelter.getShelterName().isBlank()
                || shelter.getLocation() == null
                || shelter.getLocation().isBlank()) {
            throw new IllegalArgumentException(
                    "Shelter name and location are required.");
        }

        if (shelter.getCapacity() <= 0
                || shelter.getOccupants() < 0
                || shelter.getOccupants() > shelter.getCapacity()) {
            throw new IllegalArgumentException(
                    "Invalid shelter capacity or occupant count.");
        }

        if (shelter.getAvailability() == null
                || shelter.getAvailability().isBlank()) {
            throw new IllegalArgumentException(
                    "Shelter availability is required.");
        }
    }
}
