/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package database;

import model.DisasterReport;
import java.time.LocalDateTime;
import java.util.List;

public class TestDisasterReportDAO {

    public static void main(String[] args) {
        try {
            DisasterReportDAO dao = new DisasterReportDAO();

            DisasterReport report = new DisasterReport(
                    0,
                    "DAO Test",
                    "Sydney Test Location",
                    LocalDateTime.now(),
                    "Temporary report created to test MySQL storage.",
                    2,
                    5,
                    "Minor"
            );

            // Save the report to MySQL
            dao.save(report);

            System.out.println("Report saved successfully.");
            System.out.println("Generated ID: " + report.getDisasterId());

            // Retrieve reports from MySQL
            List<DisasterReport> reports = dao.findAll();

            System.out.println("Total reports retrieved: "
                    + reports.size());

            for (DisasterReport savedReport : reports) {
                System.out.println(savedReport);
            }

        } catch (Exception e) {
            System.out.println("DAO test failed.");
            e.printStackTrace();
        }
    }
}
