/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package database;

/**
 *
 * @author Keerthi
 */
import java.sql.Connection;
import java.sql.SQLException;
public class TestDatabaseConnection {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            if (connection != null && connection.isValid(2)) {
                System.out.println("Connected to MySQL successfully!");
                System.out.println("Database: "
                        + connection.getCatalog());
            }
        } catch (SQLException e) {
            System.out.println("Database connection failed.");
            System.out.println(e.getMessage());
        }
    }
    
}
