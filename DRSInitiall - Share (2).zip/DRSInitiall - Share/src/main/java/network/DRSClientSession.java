/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package network;

public final class DRSClientSession {

    private static DRSClient client;

    private DRSClientSession() {
    }

    public static synchronized void setClient(DRSClient newClient) {
        close();
        client = newClient;
    }

    public static synchronized DRSClient getClient() {
        return client;
    }

    public static synchronized void close() {
        if (client != null) {
            client.close();
            client = null;
        }
    }
}

