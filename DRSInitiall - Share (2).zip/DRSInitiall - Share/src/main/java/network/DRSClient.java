
package network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.DisasterReport;

public class DRSClient implements AutoCloseable {

    private final String host;
    private final int port;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;

    public DRSClient(String host, int port) {
        this.host = host;
        this.port = port;
    }

    public synchronized void connect() throws IOException {
        if (socket != null && socket.isConnected()
                && !socket.isClosed()) {
            return;
        }

        close();

        Socket newSocket = new Socket();

        try {
            newSocket.connect(
                    new InetSocketAddress(host, port), 5000);
            newSocket.setSoTimeout(5000);

            BufferedReader newIn = new BufferedReader(
                    new InputStreamReader(
                            newSocket.getInputStream(),
                            StandardCharsets.UTF_8));

            PrintWriter newOut = new PrintWriter(
                    newSocket.getOutputStream(), true,
                    StandardCharsets.UTF_8);

            socket = newSocket;
            in = newIn;
            out = newOut;

        } catch (IOException e) {
            try {
                newSocket.close();
            } catch (IOException ignored) {
                // Preserve the original connection error.
            }
            throw e;
        }
    }

    public synchronized String authenticate(
            String username, String password, String role)
            throws IOException {

        if (username == null || username.isBlank()
                || password == null || password.isEmpty()
                || role == null || role.isBlank()
                || username.contains("|")
                || password.contains("|")
                || role.contains("|")
                || username.contains("\n")
                || password.contains("\n")
                || role.contains("\n")
                || username.contains("\r")
                || password.contains("\r")
                || role.contains("\r")) {
            throw new IllegalArgumentException(
                    "Invalid authentication fields.");
        }

        connect();

        String response = sendRequest(
                "AUTH|" + username + "|" + password + "|" + role);

        if (!response.startsWith("AUTH_OK|")) {
            close();
            throw new IOException(
                    "Server authentication failed: " + response);
        }

        return response;
    }

    public synchronized String sendRequest(String request)
            throws IOException {

        if (request == null || request.isBlank()
                || request.contains("\n")
                || request.contains("\r")) {
            throw new IllegalArgumentException(
                    "Request must be a non-empty single line.");
        }

        connect();

        out.println(request);

        if (out.checkError()) {
            close();
            throw new IOException(
                    "Failed to send request to the server.");
        }

        String response = in.readLine();

        if (response == null) {
            close();
            throw new IOException(
                    "Server closed the connection without a response.");
        }

        return response;
    }
    
public synchronized List<DisasterReport> getReports()
        throws IOException {

    String response = sendRequest("GET_REPORTS");

    if (response.startsWith("ERROR:")) {
        throw new IOException(response);
    }

    if (!response.equals("REPORTS")
            && !response.startsWith("REPORTS|")) {
        throw new IOException(
                "Unexpected server response for reports.");
    }

    List<DisasterReport> reports = new ArrayList<>();

    if ("REPORTS".equals(response)) {
        return reports;
    }

    String[] records = response.split("\\|", -1);

    for (int i = 1; i < records.length; i++) {
        String[] fields = records[i].split(",", -1);

        if (fields.length != 11) {
            throw new IOException(
                    "Invalid report data received from server. "
            + "Expected 11 fields but received "
            + fields.length + ". Record: " + records[i]);
        }

        try {
            DisasterReport report = new DisasterReport();

            report.setDisasterId(Integer.parseInt(fields[0]));
            report.setDisasterType(fields[1]);
            report.setLocation(fields[2]);

            report.setDateTime(fields[3].isBlank()
                    ? null : LocalDateTime.parse(fields[3]));

            report.setDescription(fields[4]);
            report.setSeverity(Integer.parseInt(fields[5]));
            report.setPeopleAffected(Integer.parseInt(fields[6]));
            report.setInfrastructureImpact(fields[7]);
            report.setPriority(fields[8]);
            report.setStatus(fields[9]);
            report.setAssignedDepartment(fields[10]);

            reports.add(report);

        } catch (IllegalArgumentException e) {
            throw new IOException(
                    "Could not parse a disaster report.", e);
        }
    }

    return reports;
}


    @Override
    public synchronized void close() {
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException ignored) {
            // Connection cleanup.
        } finally {
            socket = null;
            in = null;
            out = null;
        }
    }
}
