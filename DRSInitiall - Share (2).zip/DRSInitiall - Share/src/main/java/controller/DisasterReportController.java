
package controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import model.DRSData;
import model.DisasterReport;
import model.SafetyAdvice;
import security.UserSession;

public class DisasterReportController {

    @FXML
    private ComboBox<String> disasterTypeCombo;

    @FXML
    private TextField locationField;

    @FXML
    private ComboBox<Integer> severityCombo;

    @FXML
    private TextField peopleAffectedField;

    @FXML
    private ComboBox<String> impactCombo;

    @FXML
    private TextArea descriptionArea;

    @FXML
    private Label resultLabel;

    @FXML
    private Label safetyAdviceLabel;

    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 5000;

    @FXML
    public void initialize() {
        disasterTypeCombo.getItems().addAll(
                "Fire", "Earthquake", "Flood", "Hurricane"
        );

        severityCombo.getItems().addAll(1, 2, 3, 4, 5);

        impactCombo.getItems().addAll(
                "None", "Minor", "Moderate", "Severe"
        );
    }

    @FXML
    private void handleSubmit() {

        String type = disasterTypeCombo.getValue();
        String location = locationField.getText().trim();
        Integer severity = severityCombo.getValue();
        String peopleText = peopleAffectedField.getText().trim();
        String impact = impactCombo.getValue();
        String description = descriptionArea.getText().trim();

        if (type == null || location.isEmpty()
                || severity == null || peopleText.isEmpty()
                || impact == null || description.isEmpty()) {
            resultLabel.setText(
                    "Please complete all required fields."
            );
            return;
        }

        int peopleAffected;

        try {
            peopleAffected = Integer.parseInt(peopleText);

            if (peopleAffected < 0) {
                resultLabel.setText(
                        "People affected cannot be negative."
                );
                return;
            }
        } catch (NumberFormatException e) {
            resultLabel.setText(
                    "Enter a valid number for people affected."
            );
            return;
        }

        if (description.contains("|")
                || type.contains("|")
                || location.contains("|")
                || impact.contains("|")) {
            resultLabel.setText(
                    "Please remove the | character from the fields."
            );
            return;
        }

        String request = "SUBMIT_REPORT|"
                + type + "|"
                + location + "|"
                + severity + "|"
                + peopleAffected + "|"
                + impact + "|"
                + description.replace("\r", " ")
                              .replace("\n", " ");

        try (Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
             PrintWriter output = new PrintWriter(
             socket.getOutputStream(), true);
             BufferedReader input = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()))) {

            String username = UserSession.getUsername();
            String role = UserSession.getRole();

            if (username == null || role == null
            || !"Public User".equals(role)){
                resultLabel.setText("Please log in as a Public User.");
                        
                
                return;
            }
            javafx.scene.control.TextInputDialog passwordDialog =
            new javafx.scene.control.TextInputDialog();

    passwordDialog.setTitle("Server Authentication");
    passwordDialog.setHeaderText("Verify your account");
    passwordDialog.setContentText("Enter your password:");
    java.util.Optional<String> passwordResult =
            passwordDialog.showAndWait();


            if (passwordResult.isEmpty()
            || passwordResult.get().isEmpty()){
                resultLabel.setText("Authentication cancelled.");
        return;
           }
String password = passwordResult.get();

    output.println("AUTH|" + username + "|" + password + "|" + role);
    String authResponse = input.readLine();
if (authResponse == null
            || !authResponse.startsWith("AUTH_OK|")) {
        resultLabel.setText("Server authentication failed.");
        return;
    }
output.println(request);
    String response = input.readLine();

    if (response == null) {
        resultLabel.setText(
                "The server closed the connection unexpectedly.");
        return;
    }

    if (response.startsWith("SAVED|")) {
        int databaseId = Integer.parseInt(
                response.substring("SAVED|".length()));

        DisasterReport report = new DisasterReport(
                databaseId, type, location, LocalDateTime.now(),
                description, severity, peopleAffected, impact);

        DRSData.addDisasterReport(report);

        SafetyAdvice safetyAdvice = new SafetyAdvice();

        resultLabel.setText(
                "Report saved to MySQL successfully.\n" + report);
        safetyAdviceLabel.setText(safetyAdvice.getAdvice(type));

    } else if (response.startsWith("ERROR:")) {
        resultLabel.setText(
                "Report was not saved: "
                + response.substring("ERROR:".length()).trim());
    } else {
        resultLabel.setText(
                "Unexpected response from the server: " + response);
    }

} catch (IOException e) {
    resultLabel.setText(
            "Could not connect to the DRS server. "
            + "Ensure the server is running on port 5000.");
} catch (NumberFormatException e) {
    resultLabel.setText("The server returned an invalid report ID.");
}



            
    }

    @FXML
    private void handleClear() {
        disasterTypeCombo.setValue(null);
        locationField.clear();
        severityCombo.setValue(null);
        peopleAffectedField.clear();
        impactCombo.setValue(null);
        descriptionArea.clear();
        resultLabel.setText("");
        safetyAdviceLabel.setText("");
    }

    @FXML
    private void handleLogout() throws IOException {
        Parent root = FXMLLoader.load(
                getClass().getResource("/view/login.fxml")
        );

        Stage stage = (Stage) locationField.getScene().getWindow();
        stage.setScene(new Scene(root));
        stage.setTitle("Disaster Response System");
        stage.sizeToScene();
        stage.centerOnScreen();
    }
}
