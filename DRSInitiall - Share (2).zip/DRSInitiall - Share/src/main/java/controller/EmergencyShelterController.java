package controller;

import model.EmergencyShelter;
import network.DRSClient;
import network.DRSClientSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class EmergencyShelterController {

    @FXML
    private TextField nameField;

    @FXML
    private TextField locationField;

    @FXML
    private TextField capacityField;

    @FXML
    private TextField occupantsField;

    @FXML
    private TextField contactField;

    @FXML
    private Label messageLabel;

    @FXML
    private TableView<EmergencyShelter> shelterTable;

    @FXML
    private TableColumn<EmergencyShelter, Number> idColumn;

    @FXML
    private TableColumn<EmergencyShelter, String> nameColumn;

    @FXML
    private TableColumn<EmergencyShelter, String> locationColumn;

    @FXML
    private TableColumn<EmergencyShelter, Number> capacityColumn;

    @FXML
    private TableColumn<EmergencyShelter, Number> occupantsColumn;

    @FXML
    private TableColumn<EmergencyShelter, Number> availableColumn;

    @FXML
    private TableColumn<EmergencyShelter, String> statusColumn;

    @FXML
    private TableColumn<EmergencyShelter, String> contactColumn;

    // Get the authenticated connection to the server.
    private DRSClient getClient() {

        DRSClient client = DRSClientSession.getClient();

        if (client == null) {
            throw new IllegalStateException(
                "No authenticated server connection. "
                + "Please log in again."
            );
        }

        return client;
    }

    // Load emergency shelters through the server.
    private List<EmergencyShelter> loadSheltersFromServer()
            throws IOException {

        String response = getClient().sendRequest(
            "GET_SHELTERS"
        );

        // FIX: An empty database returns "SHELTERS".
        if (response == null ||
                !(response.equals("SHELTERS") ||
                  response.startsWith("SHELTERS|"))) {

            throw new IOException(
                "Invalid shelter response: " + response
            );
        }

        List<EmergencyShelter> shelters =
                new ArrayList<>();

        // FIX: Handle the empty response correctly.
        String data = response.equals("SHELTERS")
                ? ""
                : response.substring(
                    "SHELTERS|".length()
                );

        if (data.isEmpty()) {
            return shelters;
        }

        for (String record : data.split("\\|")) {

            String[] fields = record.split(",", -1);

            if (fields.length != 7) {
                throw new IOException(
                    "Invalid shelter record: " + record
                );
            }

            try {

                EmergencyShelter shelter =
                    new EmergencyShelter(
                        Integer.parseInt(fields[0]),
                        fields[1],
                        fields[2],
                        Integer.parseInt(fields[3]),
                        Integer.parseInt(fields[4]),
                        fields[5],
                        fields[6]
                    );

                shelters.add(shelter);

            } catch (NumberFormatException e) {

                throw new IOException(
                    "Invalid numeric value in shelter record.",
                    e
                );
            }
        }

        return shelters;
    }

    // Initialise the shelter table.
    @FXML
    private void initialize() {

        idColumn.setCellValueFactory(data ->
            new SimpleIntegerProperty(
                data.getValue().getShelterId()
            )
        );

        nameColumn.setCellValueFactory(data ->
            new SimpleStringProperty(
                data.getValue().getShelterName()
            )
        );

        locationColumn.setCellValueFactory(data ->
            new SimpleStringProperty(
                data.getValue().getLocation()
            )
        );

        capacityColumn.setCellValueFactory(data ->
            new SimpleIntegerProperty(
                data.getValue().getCapacity()
            )
        );

        occupantsColumn.setCellValueFactory(data ->
            new SimpleIntegerProperty(
                data.getValue().getOccupants()
            )
        );

        availableColumn.setCellValueFactory(data ->
            new SimpleIntegerProperty(
                data.getValue().getAvailablePlaces()
            )
        );

        statusColumn.setCellValueFactory(data ->
            new SimpleStringProperty(
                data.getValue().getAvailability()
            )
        );

        contactColumn.setCellValueFactory(data ->
            new SimpleStringProperty(
                data.getValue().getContactNumber()
            )
        );

        handleRefresh();
    }

    // Refresh the shelter table.
    @FXML
    private void handleRefresh() {

        try {

            List<EmergencyShelter> shelters =
                loadSheltersFromServer();

            shelterTable.setItems(
                FXCollections.observableArrayList(
                    shelters
                )
            );

            messageLabel.setText(
                "Shelters loaded successfully. Total: "
                + shelters.size()
            );

        } catch (IOException | IllegalStateException e) {

            messageLabel.setText(
                "Could not load shelters: "
                + e.getMessage()
            );
        }
    }

    // Add a new emergency shelter.
    @FXML
    private void handleAddShelter() {

        try {

            String name =
                nameField.getText().trim();

            String location =
                locationField.getText().trim();

            String contact =
                contactField.getText().trim();

            if (name.isEmpty() || location.isEmpty()) {

                messageLabel.setText(
                    "Shelter name and location are required."
                );

                return;
            }

            int capacity = Integer.parseInt(
                capacityField.getText().trim()
            );

            int occupants = Integer.parseInt(
                occupantsField.getText().trim()
            );

            if (capacity <= 0 ||
                    occupants < 0 ||
                    occupants > capacity) {

                messageLabel.setText(
                    "Enter valid capacity and occupancy values."
                );

                return;
            }

            String availability =
                occupants == capacity
                    ? "Full"
                    : "Available";

            // Prevent reserved protocol characters.
            if (containsReservedCharacters(name) ||
                    containsReservedCharacters(location) ||
                    containsReservedCharacters(contact)) {

                messageLabel.setText(
                    "Shelter details cannot contain "
                    + "|, commas or line breaks."
                );

                return;
            }

            String request =
                "ADD_SHELTER|"
                + name + "|"
                + location + "|"
                + capacity + "|"
                + occupants + "|"
                + availability + "|"
                + contact;

            String response =
                getClient().sendRequest(request);

            if (response != null &&
                    response.startsWith("SHELTER_SAVED|")) {

                // Clear the form after successful saving.
                nameField.clear();
                locationField.clear();
                capacityField.clear();
                occupantsField.clear();
                contactField.clear();

                handleRefresh();

                messageLabel.setText(
                    "Shelter added successfully. "
                    + response
                );

            } else {

                messageLabel.setText(
                    "Could not add shelter: "
                    + response
                );
            }

        } catch (NumberFormatException e) {

            messageLabel.setText(
                "Capacity and occupants must be whole numbers."
            );

        } catch (IOException | IllegalStateException e) {

            messageLabel.setText(
                "Server error: "
                + e.getMessage()
            );
        }
    }

    // Update occupancy of the selected shelter.
    @FXML
    private void handleUpdateOccupancy() {

        EmergencyShelter selected =
            shelterTable.getSelectionModel()
                .getSelectedItem();

        if (selected == null) {

            messageLabel.setText(
                "Please select a shelter from the table."
            );

            return;
        }

        try {

            int occupants = Integer.parseInt(
                occupantsField.getText().trim()
            );

            if (occupants < 0 ||
                    occupants > selected.getCapacity()) {

                messageLabel.setText(
                    "Occupants must be between 0 and "
                    + selected.getCapacity()
                );

                return;
            }

            String request =
                "UPDATE_OCCUPANTS|"
                + selected.getShelterId()
                + "|"
                + occupants;

            String response =
                getClient().sendRequest(request);

            if ("OCCUPANTS_UPDATED".equals(response)) {

                handleRefresh();

                messageLabel.setText(
                    "Shelter occupancy updated successfully."
                );

            } else {

                messageLabel.setText(
                    "Could not update occupancy: "
                    + response
                );
            }

        } catch (NumberFormatException e) {

            messageLabel.setText(
                "Enter a valid number in the Occupants field."
            );

        } catch (IOException | IllegalStateException e) {

            messageLabel.setText(
                "Server error: "
                + e.getMessage()
            );
        }
    }

    // Protect the existing text-based network protocol.
    private boolean containsReservedCharacters(String value) {

        return value.contains("|")
                || value.contains(",")
                || value.contains("\n")
                || value.contains("\r");
    }
}