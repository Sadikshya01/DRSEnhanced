package controller;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import security.AuthenticationService;
import java.sql.SQLException;
import security.UserSession;
import network.DRSClient;
import network.DRSClientSession;

public class LoginController {
    private final AuthenticationService authService =
        new AuthenticationService();

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private ComboBox<String> roleComboBox;

    @FXML
    private Label messageLabel;

    @FXML
    public void initialize() {

        roleComboBox.getItems().addAll(
                "Public User",
                "Disaster Response Officer"
        );
    }

    

@FXML
private void handleLogin() {

    String username = usernameField.getText().trim();
    String password = passwordField.getText();
    String role = roleComboBox.getValue();

    if (username.isEmpty() || password.isEmpty() || role == null) {
        messageLabel.setText("Please complete all fields.");
        return;
    }

    DRSClient client = null;

    try {
        // Validate credentials using the existing authentication service.
        String authenticatedRole =
                authService.authenticate(username, password, role);

        if (authenticatedRole == null) {
            messageLabel.setText(
                    "Invalid username, password, or role.");
            return;
        }

        // Establish and authenticate the persistent server connection.
        client = new DRSClient("localhost", 5000);
        client.authenticate(username, password, authenticatedRole);

        // Store the client only after server authentication succeeds.
        DRSClientSession.setClient(client);
        UserSession.setUser(username, authenticatedRole);

        if ("Public User".equals(authenticatedRole)) {
            openScreen("/view/disasterReport.fxml", "Report a Disaster");

        } else if ("Disaster Response Officer".equals(authenticatedRole)) {
            openScreen(
                    "/view/officerDashboard.fxml",
                    "Disaster Response Officer Dashboard");
        }

        // The session now owns the client connection.
        client = null;

    } catch (SQLException e) {
        messageLabel.setText(
                "Unable to verify login. Please try again.");
        e.printStackTrace();

    } catch (IOException | IllegalArgumentException e) {
        messageLabel.setText(
                "Unable to connect to the response server. Please try again.");
        e.printStackTrace();

    } finally {
        // Close any connection that wasn't transferred to the session.
        if (client != null) {
            client.close();
        }
    }
}

    private void openScreen(String fxml,
                            String title) throws IOException {

        Parent root = FXMLLoader.load(
                getClass().getResource(fxml)
        );

        Stage stage =
                (Stage) usernameField.getScene().getWindow();

        stage.setScene(new Scene(root));
        stage.setTitle(title);
        stage.sizeToScene();
        stage.centerOnScreen();
    }
}