
package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import database.DisasterReportDAO;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import model.DRSData;
import model.DepartmentRecommendation;
import model.DisasterAssessment;
import model.DisasterReport;
import network.DRSClient;
import network.DRSClientSession;

public class OfficerDashboardController {
    private DRSClient getClient() {
    DRSClient client = DRSClientSession.getClient();

    if (client == null) {
        throw new IllegalStateException(
                "No authenticated server connection. Please log in again.");
    }

    return client;
}

    private final DisasterReportDAO reportDAO =
            new DisasterReportDAO();

    @FXML
    private TableView<DisasterReport> disasterTable;

    @FXML
    private TableColumn<DisasterReport, Number> idColumn;

    @FXML
    private TableColumn<DisasterReport, String> typeColumn;

    @FXML
    private TableColumn<DisasterReport, String> locationColumn;

    @FXML
    private TableColumn<DisasterReport, Number> severityColumn;

    @FXML
    private TableColumn<DisasterReport, String> priorityColumn;

    @FXML
    private TableColumn<DisasterReport, String> statusColumn;

    @FXML
    private TableColumn<DisasterReport, String> departmentColumn;

    @FXML
    private ComboBox<String> priorityCombo;

    @FXML
    private ComboBox<String> departmentCombo;

    @FXML
    private ComboBox<String> statusCombo;

    @FXML
    private Label messageLabel;

    @FXML
    public void initialize() {

        priorityCombo.getItems().addAll(
                "Low", "Medium", "High", "Critical"
        );

        departmentCombo.getItems().addAll(
                "Fire and Emergency Services",
                "Hospital",
                "Law Enforcement",
                "Electricity",
                "Transportation",
                "Waste Management",
                "Water Supply",
                "Schools"
        );

        statusCombo.getItems().addAll(
                "Reported",
                "Assigned",
                "In Progress",
                "Completed"
        );

        idColumn.setCellValueFactory(data ->
                new SimpleIntegerProperty(
                        data.getValue().getDisasterId()
                )
        );

        typeColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getDisasterType()
                )
        );

        locationColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getLocation()
                )
        );

        severityColumn.setCellValueFactory(data ->
                new SimpleIntegerProperty(
                        data.getValue().getSeverity()
                )
        );

        priorityColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getPriority()
                )
        );

        statusColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getStatus()
                )
        );

        departmentColumn.setCellValueFactory(data ->
                new SimpleStringProperty(
                        data.getValue().getAssignedDepartment()
                )
        );

        
try {
    List<DisasterReport> reports = getClient().getReports();

    DRSData.getDisasterReports().setAll(reports);
    disasterTable.setItems(DRSData.getDisasterReports());

    messageLabel.setText(
            "Loaded " + reports.size() + " reports from the server."
    );

} catch (IOException | IllegalStateException e) {
    messageLabel.setText(
            "Could not load reports from the server: " + e.getMessage()
    );
    e.printStackTrace();
}

    }

    
@FXML
private void handleAssess() {

    DisasterReport report =
            disasterTable.getSelectionModel().getSelectedItem();

    if (report == null) {
        messageLabel.setText("Please select a disaster report.");
        return;
    }

    DisasterAssessment assessment =
            new DisasterAssessment(
                    report.getSeverity(),
                    report.getPeopleAffected(),
                    report.getInfrastructureImpact()
            );

    String previousPriority = report.getPriority();
    String priority = assessment.determinePriority();

    try {
        String response = getClient().sendRequest(
                "UPDATE_PRIORITY|"
                + report.getDisasterId()
                + "|" + priority
        );

        if ("SUCCESS|PRIORITY_UPDATED".equals(response)) {
            report.setPriority(priority);
            priorityCombo.setValue(priority);
            disasterTable.refresh();

            messageLabel.setText(
                    "Assessment saved through server. Risk Score: "
                    + assessment.getRiskScore()
                    + ", Priority: " + priority
            );

            if ("Critical".equalsIgnoreCase(priority)) {
                showCriticalDisasterAlert(
                        report, assessment.getRiskScore());
            }

        } else {
            report.setPriority(previousPriority);
            messageLabel.setText(
                    "Assessment update failed: " + response);
        }

    } catch (IOException | IllegalStateException e) {
        report.setPriority(previousPriority);
        messageLabel.setText(
                "Could not save assessment through server: "
                + e.getMessage());
        e.printStackTrace();
    }
}

    private void showCriticalDisasterAlert(
            DisasterReport report, int riskScore) {

        Alert alert = new Alert(
                Alert.AlertType.WARNING,
                "",
                ButtonType.OK
        );

        alert.setTitle("Critical Disaster Alert");
        alert.setHeaderText(
                "CRITICAL DISASTER - IMMEDIATE ATTENTION REQUIRED"
        );

        alert.setContentText(
                "Disaster ID: " + report.getDisasterId()
                + "\nDisaster Type: " + report.getDisasterType()
                + "\nLocation: " + report.getLocation()
                + "\nSeverity: " + report.getSeverity()
                + "\nRisk Score: " + riskScore
                + "\nPriority: Critical"
                + "\n\nRECOMMENDED ACTION:"
                + "\nCoordinate emergency response departments immediately."
                + "\nReview department recommendations and assign responders."
        );

        if (disasterTable.getScene() != null) {
            alert.initOwner(
                    disasterTable.getScene().getWindow()
            );
        }

        alert.showAndWait();
    }

    @FXML
    private void handleRecommend() {

        DisasterReport report =
                disasterTable.getSelectionModel()
                        .getSelectedItem();

        if (report == null) {
            messageLabel.setText(
                    "Please select a disaster report."
            );
            return;
        }

        DepartmentRecommendation recommendation =
                new DepartmentRecommendation();

        List<String> departments =
                recommendation.recommendDepartments(
                        report.getDisasterType()
                );

        if (!departments.isEmpty()) {
            departmentCombo.setValue(
                    departments.get(0)
            );
        }

        messageLabel.setText(
                "Recommended departments: "
                + String.join(", ", departments)
        );
    }

    
@FXML
private void handleAssign() {

    DisasterReport report =
            disasterTable.getSelectionModel().getSelectedItem();

    String department = departmentCombo.getValue();

    if (report == null) {
        messageLabel.setText("Please select a disaster report.");
        return;
    }

    if (department == null || department.isBlank()) {
        messageLabel.setText("Please select a department.");
        return;
    }

    String previousDepartment = report.getAssignedDepartment();
    String previousStatus = report.getStatus();

    try {
        String response = getClient().sendRequest(
                "ASSIGN_DEPARTMENT|"
                + report.getDisasterId()
                + "|" + department
        );

        if ("SUCCESS|DEPARTMENT_UPDATED".equals(response)) { 
            report.setAssignedDepartment(department);
            report.setStatus("Assigned");
            statusCombo.setValue("Assigned");
            disasterTable.refresh();

            messageLabel.setText(
                    department + " assigned to Disaster ID "
                    + report.getDisasterId() + " through the server."
            );

        } else {
            report.setAssignedDepartment(previousDepartment);
            report.setStatus(previousStatus);
            messageLabel.setText("Assignment failed: " + response);
        }

    } catch (IOException | IllegalStateException e) {
        report.setAssignedDepartment(previousDepartment);
        report.setStatus(previousStatus);
        messageLabel.setText(
                "Could not assign department: " + e.getMessage());
        e.printStackTrace();
    }
}

    
@FXML
private void handleUpdateStatus() {

    DisasterReport report =
            disasterTable.getSelectionModel().getSelectedItem();

    String status = statusCombo.getValue();

    if (report == null) {
        messageLabel.setText("Please select a disaster report.");
        return;
    }

    if (status == null || status.isBlank()) {
        messageLabel.setText("Please select a response status.");
        return;
    }

    String previousStatus = report.getStatus();

    try {
        String response = getClient().sendRequest(
                "UPDATE_STATUS|"
                + report.getDisasterId()
                + "|" + status
        );

        if ("SUCCESS|STATUS_UPDATED".equals(response)) {
            report.setStatus(status);
            disasterTable.refresh();

            messageLabel.setText(
                    "Response status for Disaster ID "
                    + report.getDisasterId()
                    + " updated to " + status + " through the server."
            );

        } else {
            report.setStatus(previousStatus);
            statusCombo.setValue(previousStatus);
            messageLabel.setText("Status update failed: " + response);
        }

    } catch (IOException | IllegalStateException e) {
        report.setStatus(previousStatus);
        statusCombo.setValue(previousStatus);
        messageLabel.setText(
                "Could not update response status: " + e.getMessage());
        e.printStackTrace();
    }
}


    // NEW: Emergency Shelter Management window
    @FXML
    private void handleEmergencyShelters() {

        try {
            FXMLLoader loader = new FXMLLoader(
                    getClass().getResource(
                            "/view/emergencyShelter.fxml"
                    )
            );

            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setTitle(
                    "Emergency Shelter Management"
            );
            stage.setScene(new Scene(root));
            stage.setMinWidth(900);
            stage.setMinHeight(600);
            stage.centerOnScreen();
            stage.show();

        } catch (IOException | RuntimeException e) {

            new Alert(
                    Alert.AlertType.ERROR,
                    "Could not open Emergency Shelter Management: "
                    + e.getMessage(),
                    ButtonType.OK
            ).showAndWait();
        }
    }

    @FXML
    private void handleLogout() throws IOException {

        Parent root = FXMLLoader.load(
                getClass().getResource(
                        "/view/login.fxml"
                )
        );

        Stage stage = (Stage) disasterTable
                .getScene()
                .getWindow();

        stage.setScene(new Scene(root));
        stage.setTitle(
                "Disaster Response System"
        );
        stage.sizeToScene();
        stage.centerOnScreen();
    }
}
