/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TestRolePermissions {

    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", 5000);
             PrintWriter output = new PrintWriter(
                     socket.getOutputStream(), true);
             BufferedReader input = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()))) {

            // Authenticate as a Public User.
            // The password is read locally; do not share it.
            java.util.Scanner scanner =
                    new java.util.Scanner(System.in);

            System.out.print("Officer username: ");
            String username = scanner.nextLine();

            System.out.print("Officer password: ");
            String password = scanner.nextLine();

            output.println(
                    "AUTH|" + username + "|" + password + "|Disaster Response Officer"
            );

            String authResponse = input.readLine();
            System.out.println("Authentication: " + authResponse);

            if (authResponse == null
                    || !authResponse.equals("AUTH_OK|Disaster Response Officer")) {
                System.out.println("Could not authenticate Public User.");
                return;
            }

            // A Public User must not retrieve the officer report list.
            output.println("GET_REPORTS");
            String response = input.readLine();

            System.out.println("GET_REPORTS response: " + response);

            if (response != null && response.startsWith("REPORTS")) {
                System.out.println(
                        "PASS: Officer can retrieve disaster reports."
                );
            } else {
                System.out.println(
                        "FAIL: Officer could not retrieve disaster reports."
                );
            }

            output.println("EXIT");
            System.out.println("Exit response: " + input.readLine());

        } catch (Exception e) {
            System.err.println("Test failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

