
package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TestServerClient {

    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", 5000);
             PrintWriter output = new PrintWriter(
                     socket.getOutputStream(), true);
             BufferedReader input = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()))) {

            // Test 1: Check server connection
            output.println("PING");
            System.out.println(
                    "PING test: " + input.readLine());

            // Test 2: Retrieve existing shelters
            output.println("GET_SHELTERS");
            System.out.println(
                    "Existing shelters: " + input.readLine());

            // Test 3: Add a valid shelter
            String uniqueName =
                    "Assessment Shelter " + System.currentTimeMillis();

            output.println(
                    "ADD_SHELTER|" + uniqueName
                    + "|Sydney|50|10|Available|0400000000"
            );

            String saveResponse = input.readLine();
            System.out.println(
                    "Add shelter test: " + saveResponse);

            // Test 4: Update occupants if creation succeeded
            if (saveResponse != null
                    && saveResponse.startsWith("SHELTER_SAVED|")) {

                int shelterId = Integer.parseInt(
                        saveResponse.split("\\|")[1]);

                output.println(
                        "UPDATE_OCCUPANTS|" + shelterId + "|20");

                System.out.println(
                        "Update occupants test: "
                        + input.readLine());

                // Test 5: Retrieve shelters and verify values
                output.println("GET_SHELTERS");
                String sheltersResponse = input.readLine();

                System.out.println(
                        "Shelters after update: "
                        + sheltersResponse);

                if (sheltersResponse != null
                        && sheltersResponse.contains(
                                shelterId + "," + uniqueName
                                + ",Sydney,50,20,Available")) {
                    System.out.println(
                            "PASS: Shelter creation, update, "
                            + "and retrieval verified.");
                } else {
                    System.out.println(
                            "CHECK: Verify the saved shelter "
                            + "details in MySQL.");
                }
            }

            // Test 6: Reject invalid capacity
            output.println(
                    "ADD_SHELTER|Invalid Test Shelter"
                    + "|Sydney|0|0|Available|0400000000");

            System.out.println(
                    "Invalid capacity test: "
                    + input.readLine());

            output.println("EXIT");
            System.out.println(
                    "Exit response: " + input.readLine());

        } catch (Exception e) {
            System.err.println(
                    "Test failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
