
package server;

import database.DisasterReportDAO;
import database.EmergencyShelterDAO;
import model.DisasterReport;
import model.EmergencyShelter;
import security.AuthenticationService;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class ClientHandler implements Runnable {

    private final Socket clientSocket;
    private final DisasterReportDAO reportDAO = new DisasterReportDAO();
    private final EmergencyShelterDAO shelterDAO = new EmergencyShelterDAO();
    private final AuthenticationService authService =
            new AuthenticationService();

    private String authenticatedUsername;
    private String authenticatedRole;

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try (
            BufferedReader input = new BufferedReader(
                    new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter output = new PrintWriter(
                    clientSocket.getOutputStream(), true)
        ) {
            String request;

            while ((request = input.readLine()) != null) {
                String response = processRequest(request);
                output.println(response);

                if ("EXIT".equalsIgnoreCase(request.trim())) {
                    break;
                }
            }

        } catch (IOException e) {
            System.err.println("Client connection error: "
                    + e.getMessage());
        } finally {
            try {
                clientSocket.close();
            } catch (IOException e) {
                System.err.println("Could not close client socket: "
                        + e.getMessage());
            }
        }
    }

    private String processRequest(String request) {
        if (request == null || request.isBlank()) {
            return "ERROR: Empty request";
        }

        String command = request.trim();

        try {
            if (command.startsWith("AUTH|")) {
                return authenticateClient(command);
            }

            if ("PING".equalsIgnoreCase(command)) {
                return "PONG";
            }

            if ("EXIT".equalsIgnoreCase(command)) {
                return "BYE";
            }

            if (!isAuthenticated()) {
                return "ERROR: Authentication required";
            }
            if (command.equalsIgnoreCase("GET_REPORTS")) {
    System.out.println("Received command: GET_REPORTS");

    if (!isOfficer()) {
        System.out.println("Rejected: user is not an officer");
        return "ERROR: Officer role required";
    }

    return getReports();
}


            if (command.startsWith("UPDATE_PRIORITY|")) {
                if (!isOfficer()) return "ERROR: Officer role required";
                return updateReportField(command, "priority");
            }

            if (command.startsWith("ASSIGN_DEPARTMENT|")) {
                if (!isOfficer()) return "ERROR: Officer role required";
                return updateReportField(command, "department");
            }

            if (command.startsWith("UPDATE_STATUS|")) {
                if (!isOfficer()) return "ERROR: Officer role required";
                return updateReportField(command, "status");
            }

            if (command.equalsIgnoreCase("GET_SHELTERS")) {
                return getShelters();
            }

            if (command.startsWith("SUBMIT_REPORT|")) {
                if (!isPublicUser()) {
                    return "ERROR: Public User role required";
                }
                return submitReport(command);
            }

            if (command.startsWith("ADD_SHELTER|")) {
                if (!isOfficer()) {
                    return "ERROR: Officer role required";
                }
                return addShelter(command);
            }

            if (command.startsWith("UPDATE_OCCUPANTS|")) {
                if (!isOfficer()) {
                    return "ERROR: Officer role required";
                }
                return updateOccupants(command);
            }
            
            return "ERROR: Unsupported request";

        } catch (NumberFormatException e) {
            return "ERROR: Numeric fields must contain valid numbers";
        } catch (IllegalArgumentException e) {
            return "ERROR: " + e.getMessage();
        } catch (Exception e) {
            System.err.println("Request processing failed: "
                    + e.getMessage());
            return "ERROR: Request could not be processed";
        }
    }

    private String authenticateClient(String request) throws Exception {
        String[] parts = request.split("\\|", -1);

        if (parts.length != 4) {
            return "ERROR: Expected username, password and role";
        }

        if (isAuthenticated()) {
            return "ERROR: Connection already authenticated";
        }

        String username = parts[1];
        String password = parts[2];
        String role = parts[3];

        String verifiedRole =
                authService.authenticate(username, password, role);

        if (verifiedRole == null) {
            return "ERROR: Invalid credentials";
        }

        authenticatedUsername = username.trim();
        authenticatedRole = verifiedRole;

        return "AUTH_OK|" + authenticatedRole;
    }

    private boolean isAuthenticated() {
        return authenticatedUsername != null
                && authenticatedRole != null;
    }

    private boolean isOfficer() {
        return isAuthenticated()
                && "Disaster Response Officer".equals(authenticatedRole);
    }

    private boolean isPublicUser() {
        return isAuthenticated()
                && "Public User".equals(authenticatedRole);
    }
    

private String getShelters() throws Exception {
    List<EmergencyShelter> shelters = shelterDAO.findAll();
    StringBuilder response = new StringBuilder("SHELTERS");

    for (EmergencyShelter shelter : shelters) {
        response.append("|")
                .append(shelter.getShelterId()).append(",")
                .append(clean(shelter.getShelterName())).append(",")
                .append(clean(shelter.getLocation())).append(",")
                .append(shelter.getCapacity()).append(",")
                .append(shelter.getOccupants()).append(",")
                .append(clean(shelter.getAvailability())).append(",")
                .append(clean(shelter.getContactNumber()));
    }

    return response.toString();
}


    
private String getReports() throws Exception {
    List<DisasterReport> reports = reportDAO.findAll();
    StringBuilder response = new StringBuilder("REPORTS");

    System.out.println("GET_REPORTS reached this ClientHandler");
    System.out.println("Reports loaded from DAO: " + reports.size());

    for (DisasterReport report : reports) {
        String[] fields = {
            String.valueOf(report.getDisasterId()),
            clean(report.getDisasterType()),
            clean(report.getLocation()),
            report.getDateTime() == null
                ? "" : report.getDateTime().toString(),
            clean(report.getDescription()),
            String.valueOf(report.getSeverity()),
            String.valueOf(report.getPeopleAffected()),
            clean(report.getInfrastructureImpact()),
            clean(report.getPriority()),
            clean(report.getStatus()),
            clean(report.getAssignedDepartment())
        };

        if (fields.length != 11) {
            throw new IllegalStateException(
                "A report must contain exactly 11 fields."
            );
        }

        response.append("|").append(String.join(",", fields));
    }

    String result = response.toString();

    System.out.println("REPORTS response: " + result);
    System.out.println("Response length: " + result.length());

    return result;
}


    






    private String submitReport(String request) throws Exception {
        String[] parts = request.split("\\|", -1);

        if (parts.length != 7) {
            return "ERROR: Expected 6 report fields";
        }

        String type = parts[1].trim();
        String location = parts[2].trim();
        int severity = Integer.parseInt(parts[3]);
        int peopleAffected = Integer.parseInt(parts[4]);
        String infrastructure = parts[5].trim();
        String description = parts[6].trim();

        if (type.isEmpty() || location.isEmpty()
                || description.isEmpty()) {
            return "ERROR: Required report fields cannot be empty";
        }

        if (severity < 1 || severity > 5 || peopleAffected < 0) {
            return "ERROR: Invalid severity or people affected";
        }

        DisasterReport report = new DisasterReport(
                0, type, location, LocalDateTime.now(), description,
                severity, peopleAffected, infrastructure
        );

        reportDAO.save(report);
        return "SAVED|" + report.getDisasterId();
    }

    /** Updates one officer-managed field and persists it using the existing DAO. */
    private String updateReportField(String request, String field) throws Exception {
        String[] parts = request.split("\\|", -1);
        if (parts.length != 3) {
            return "ERROR: Expected report ID and value";
        }
        int reportId = Integer.parseInt(parts[1]);
        String value = parts[2].trim();
        if (reportId <= 0 || value.isBlank() || value.contains(",") || value.contains("|")) {
            return "ERROR: Invalid report ID or value";
        }
        if ("priority".equals(field)
                && !List.of("Low", "Medium", "High", "Critical").contains(value)) {
            return "ERROR: Invalid priority";
        }
        if ("status".equals(field)
                && !List.of("Reported", "Assigned", "In Progress", "Completed").contains(value)) {
            return "ERROR: Invalid status";
        }
        if ("department".equals(field)
                && !List.of("Fire and Emergency Services", "Hospital", "Law Enforcement",
                        "Electricity", "Transportation", "Waste Management", "Water Supply", "Schools")
                        .contains(value)) {
            return "ERROR: Invalid department";
        }
        for (DisasterReport report : reportDAO.findAll()) {
            if (report.getDisasterId() == reportId) {
                if ("priority".equals(field)) report.setPriority(value);
                else if ("status".equals(field)) report.setStatus(value);
                else {
                    report.setAssignedDepartment(value);
                    if ("Reported".equals(report.getStatus())) report.setStatus("Assigned");
                }
                boolean updated = reportDAO.update(report);
                return updated ? "SUCCESS|" + field.toUpperCase() + "_UPDATED"
                        : "ERROR: Report update failed";
            }
        }
        return "ERROR: Report not found";
    }

    

    private String addShelter(String request) throws Exception {
        String[] parts = request.split("\\|", -1);

        if (parts.length != 7) {
            return "ERROR: Expected 6 shelter fields";
        }

        String name = parts[1].trim();
        String location = parts[2].trim();
        int capacity = Integer.parseInt(parts[3]);
        int occupants = Integer.parseInt(parts[4]);
        String availability = parts[5].trim();
        String contact = parts[6].trim();

        EmergencyShelter shelter = new EmergencyShelter(
                0, name, location, capacity, occupants,
                availability, contact
        );

        shelterDAO.save(shelter);
        return "SHELTER_SAVED|" + shelter.getShelterId();
    }

    private String updateOccupants(String request) throws Exception {
        String[] parts = request.split("\\|", -1);

        if (parts.length != 3) {
            return "ERROR: Expected shelter ID and occupant count";
        }

        int shelterId = Integer.parseInt(parts[1]);
        int occupants = Integer.parseInt(parts[2]);

        if (shelterId <= 0 || occupants < 0) {
            return "ERROR: Invalid shelter ID or occupant count";
        }

        boolean updated =
                shelterDAO.updateOccupants(shelterId, occupants);

        return updated
                ? "OCCUPANTS_UPDATED"
                : "ERROR: Shelter not found or occupancy exceeds capacity";
    }
    private String updatePriority(String request) throws Exception {
    String[] parts = request.split("\\|", -1);

    if (parts.length != 3) {
        return "ERROR: Expected report ID and priority";
    }

    int reportId = Integer.parseInt(parts[1]);
    String priority = parts[2].trim();

    if (reportId <= 0 || priority.isEmpty()) {
        return "ERROR: Invalid report ID or priority";
    }

    DisasterReport report = findReport(reportId);
    if (report == null) {
        return "ERROR: Report not found";
    }

    report.setPriority(priority);

    return reportDAO.update(report)
            ? "PRIORITY_UPDATED"
            : "ERROR: Priority update failed";
}

private String assignDepartment(String request) throws Exception {
    String[] parts = request.split("\\|", -1);

    if (parts.length != 3) {
        return "ERROR: Expected report ID and department";
    }

    int reportId = Integer.parseInt(parts[1]);
    String department = parts[2].trim();

    if (reportId <= 0 || department.isEmpty()) {
        return "ERROR: Invalid report ID or department";
    }

    DisasterReport report = findReport(reportId);
    if (report == null) {
        return "ERROR: Report not found";
    }

    report.setAssignedDepartment(department);
    report.setStatus("Assigned");

    return reportDAO.update(report)
            ? "DEPARTMENT_ASSIGNED"
            : "ERROR: Department assignment failed";
}

private String updateStatus(String request) throws Exception {
    String[] parts = request.split("\\|", -1);

    if (parts.length != 3) {
        return "ERROR: Expected report ID and status";
    }

    int reportId = Integer.parseInt(parts[1]);
    String status = parts[2].trim();

    if (reportId <= 0 || status.isEmpty()) {
        return "ERROR: Invalid report ID or status";
    }

    DisasterReport report = findReport(reportId);
    if (report == null) {
        return "ERROR: Report not found";
    }

    report.setStatus(status);

    return reportDAO.update(report)
            ? "STATUS_UPDATED"
            : "ERROR: Status update failed";
}

private DisasterReport findReport(int reportId) throws Exception {
    for (DisasterReport report : reportDAO.findAll()) {
        if (report.getDisasterId() == reportId) {
            return report;
        }
    }
    return null;
}

    private String clean(String value) {
        if (value == null) {
            return "";
        }

        return value.replace("|", "/")
                    .replace(",", ";")
                    .replace("\r", " ")
                    .replace("\n", " ");
    }
}
