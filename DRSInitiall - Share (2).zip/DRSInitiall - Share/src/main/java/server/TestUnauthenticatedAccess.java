/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package server;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class TestUnauthenticatedAccess {

    public static void main(String[] args) {

        try (Socket socket = new Socket("localhost", 5000);
             PrintWriter output = new PrintWriter(
                     socket.getOutputStream(), true);
             BufferedReader input = new BufferedReader(
                     new InputStreamReader(
                             socket.getInputStream()))) {

            // Attempt to submit a report without authenticating.
            output.println(
                    "SUBMIT_REPORT|Fire|Security Test Location"
                    + "|2|1|Minor|Unauthorised test report"
            );

            String response = input.readLine();

            System.out.println(
                    "Unauthenticated report submission: " + response
            );

            if ("ERROR: Authentication required".equals(response)) {
                System.out.println(
                        "PASS: Unauthenticated report submission rejected."
                );
            } else {
                System.out.println(
                        "FAIL: Unexpected response. Investigate server security."
                );
            }

            output.println("EXIT");
            System.out.println("Exit response: " + input.readLine());

        } catch (Exception e) {
            System.err.println("Test failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
