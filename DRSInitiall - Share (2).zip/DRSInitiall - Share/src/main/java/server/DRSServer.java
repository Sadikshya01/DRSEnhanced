/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DRSServer {

    private static final int PORT = 5000;
    private static final int THREAD_POOL_SIZE = 10;

    private final ExecutorService threadPool =
            Executors.newFixedThreadPool(THREAD_POOL_SIZE);

    public void start() {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {

            System.out.println("DRS Server started on port " + PORT);
            System.out.println("Waiting for client connections...");

            while (!Thread.currentThread().isInterrupted()) {
                Socket clientSocket = serverSocket.accept();

                System.out.println("Client connected: "
                        + clientSocket.getRemoteSocketAddress());

                threadPool.submit(new ClientHandler(clientSocket));
            }

        } catch (IOException e) {
            System.err.println("Server error: " + e.getMessage());
        } finally {
            threadPool.shutdown();
        }
    }

    public static void main(String[] args) {
        new DRSServer().start();
    }
}
