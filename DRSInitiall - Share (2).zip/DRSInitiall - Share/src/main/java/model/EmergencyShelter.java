/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package model;

public class EmergencyShelter {

    private int shelterId;
    private String shelterName;
    private String location;
    private int capacity;
    private int occupants;
    private String availability;
    private String contactNumber;

    public EmergencyShelter() {
    }

    public EmergencyShelter(
            int shelterId,
            String shelterName,
            String location,
            int capacity,
            int occupants,
            String availability,
            String contactNumber) {

        this.shelterId = shelterId;
        this.shelterName = shelterName;
        this.location = location;
        this.capacity = capacity;
        this.occupants = occupants;
        this.availability = availability;
        this.contactNumber = contactNumber;
    }

    public int getShelterId() {
        return shelterId;
    }

    public void setShelterId(int shelterId) {
        this.shelterId = shelterId;
    }

    public String getShelterName() {
        return shelterName;
    }

    public void setShelterName(String shelterName) {
        this.shelterName = shelterName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getOccupants() {
        return occupants;
    }

    public void setOccupants(int occupants) {
        this.occupants = occupants;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public int getAvailablePlaces() {
        return capacity - occupants;
    }
}
