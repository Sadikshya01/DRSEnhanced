/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package security;

public final class UserSession {

    private static String username;
    private static String role;

    private UserSession() {
    }

    public static void setUser(String authenticatedUsername,
                               String authenticatedRole) {
        username = authenticatedUsername;
        role = authenticatedRole;
    }

    public static String getUsername() {
        return username;
    }

    public static String getRole() {
        return role;
    }

    public static boolean isLoggedIn() {
        return username != null && role != null;
    }

    public static void clear() {
        username = null;
        role = null;
    }
}
