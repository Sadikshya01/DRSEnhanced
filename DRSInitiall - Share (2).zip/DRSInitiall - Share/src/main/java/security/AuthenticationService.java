/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package security;

import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.mindrot.jbcrypt.BCrypt;

public class AuthenticationService {

    public String authenticate(
            String username,
            String password,
            String selectedRole) throws SQLException {

        if (username == null || username.isBlank()
                || password == null || password.isEmpty()
                || selectedRole == null || selectedRole.isBlank()) {
            return null;
        }

        String sql = """
            SELECT password_hash, role
            FROM users
            WHERE username = ?
            """;

        try (Connection connection =
                     DatabaseConnection.getConnection();
             PreparedStatement statement =
                     connection.prepareStatement(sql)) {

            statement.setString(1, username.trim());

            try (ResultSet result = statement.executeQuery()) {

                if (!result.next()) {
                    return null;
                }

                String storedHash =
                        result.getString("password_hash");
                String storedRole =
                        result.getString("role");

                if (storedHash == null || storedRole == null) {
                    return null;
                }

                if (!BCrypt.checkpw(password, storedHash)) {
                    return null;
                }

                if (!storedRole.equals(selectedRole)) {
                    return null;
                }

                return storedRole;
            }
        }
    }

    public String hashPassword(String password) {
        if (password == null || password.length() < 12) {
            throw new IllegalArgumentException(
                    "Password must contain at least 12 characters.");
        }

        return BCrypt.hashpw(password, BCrypt.gensalt(12));
    }
}
