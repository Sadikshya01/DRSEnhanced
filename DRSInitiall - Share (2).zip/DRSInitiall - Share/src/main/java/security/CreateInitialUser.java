/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package security;

import database.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class CreateInitialUser {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AuthenticationService authService = new AuthenticationService();

        System.out.print("Enter username: ");
        String username = scanner.nextLine().trim();

        System.out.print("Enter role (Public User or Disaster Response Officer): ");
        String role = scanner.nextLine().trim();

        System.out.print("Enter password (minimum 12 characters): ");
        String password = scanner.nextLine();

        if (username.isBlank()
                || (!role.equals("Public User")
                && !role.equals("Disaster Response Officer"))) {
            System.out.println("Invalid username or role.");
            return;
        }

        try {
            String passwordHash = authService.hashPassword(password);

            String sql = """
                INSERT INTO users (username, password_hash, role)
                VALUES (?, ?, ?)
                """;

            try (Connection connection = DatabaseConnection.getConnection();
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                statement.setString(1, username);
                statement.setString(2, passwordHash);
                statement.setString(3, role);
                statement.executeUpdate();

                System.out.println("User account created successfully.");
            }

        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println(
                "Account creation failed. The username may already exist."
            );
            e.printStackTrace();
        }
    }
}

