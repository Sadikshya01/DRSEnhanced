/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package database;

import model.EmergencyShelter;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class EmergencyShelterDAOTest {

    private final EmergencyShelterDAO dao =
            new EmergencyShelterDAO();

    @Test
    void saveShelterGeneratesIdAndPersistsData()
            throws Exception {

        String uniqueName =
                "JUnit Shelter " + System.currentTimeMillis();

        EmergencyShelter shelter = new EmergencyShelter(
                0,
                uniqueName,
                "Sydney",
                50,
                10,
                "Available",
                "0400000000"
        );

        dao.save(shelter);

        assertTrue(
                shelter.getShelterId() > 0,
                "MySQL should generate a shelter ID"
        );

        List<EmergencyShelter> shelters = dao.findAll();

        EmergencyShelter saved = shelters.stream()
                .filter(s -> s.getShelterId()
                        == shelter.getShelterId())
                .findFirst()
                .orElse(null);

        assertNotNull(saved);
        assertEquals(uniqueName, saved.getShelterName());
        assertEquals("Sydney", saved.getLocation());
        assertEquals(50, saved.getCapacity());
        assertEquals(10, saved.getOccupants());
        assertEquals("Available", saved.getAvailability());
    }

    @Test
    void updateOccupantsChangesOccupancyAndAvailability()
            throws Exception {

        String uniqueName =
                "JUnit Occupancy " + System.currentTimeMillis();

        EmergencyShelter shelter = new EmergencyShelter(
                0,
                uniqueName,
                "Sydney",
                10,
                2,
                "Available",
                "0400000000"
        );

        dao.save(shelter);

        assertTrue(
                dao.updateOccupants(shelter.getShelterId(), 10),
                "Existing shelter should be updated"
        );

        EmergencyShelter updated = dao.findAll().stream()
                .filter(s -> s.getShelterId()
                        == shelter.getShelterId())
                .findFirst()
                .orElse(null);

        assertNotNull(updated);
        assertEquals(10, updated.getOccupants());
        assertEquals("Full", updated.getAvailability());
    }

    @Test
    void updateOccupantsRejectsCountAboveCapacity()
            throws Exception {

        String uniqueName =
                "JUnit Capacity " + System.currentTimeMillis();

        EmergencyShelter shelter = new EmergencyShelter(
                0,
                uniqueName,
                "Sydney",
                5,
                2,
                "Available",
                "0400000000"
        );

        dao.save(shelter);

        assertFalse(
                dao.updateOccupants(shelter.getShelterId(), 6),
                "Occupancy above capacity should be rejected"
        );
    }

    @Test
    void saveShelterRejectsInvalidCapacity() {

        EmergencyShelter shelter = new EmergencyShelter(
                0,
                "Invalid JUnit Shelter",
                "Sydney",
                0,
                0,
                "Available",
                "0400000000"
        );

        assertThrows(
                IllegalArgumentException.class,
                () -> dao.save(shelter)
        );
    }
}
