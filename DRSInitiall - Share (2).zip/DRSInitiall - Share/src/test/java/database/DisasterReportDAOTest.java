/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package database;

import model.DisasterReport;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class DisasterReportDAOTest {

    private final DisasterReportDAO dao =
            new DisasterReportDAO();

    @Test
    void saveReportGeneratesIdAndPersistsReport()
            throws Exception {

        String uniqueLocation =
                "DAO-JUnit-" + System.currentTimeMillis();

        DisasterReport report = new DisasterReport(
                0,
                "Flood",
                uniqueLocation,
                LocalDateTime.now(),
                "JUnit database persistence test",
                3,
                12,
                "Moderate"
        );

        dao.save(report);

        assertTrue(
                report.getDisasterId() > 0,
                "MySQL should generate a report ID"
        );

        List<DisasterReport> reports = dao.findAll();

        DisasterReport savedReport = reports.stream()
                .filter(r -> r.getDisasterId()
                        == report.getDisasterId())
                .findFirst()
                .orElse(null);

        assertNotNull(savedReport);
        assertEquals("Flood", savedReport.getDisasterType());
        assertEquals(uniqueLocation, savedReport.getLocation());
        assertEquals(
                "JUnit database persistence test",
                savedReport.getDescription()
        );
    }

    @Test
    void updateReportPersistsPriorityStatusAndDepartment()
            throws Exception {

        String uniqueLocation =
                "DAO-Update-" + System.currentTimeMillis();

        DisasterReport report = new DisasterReport(
                0,
                "Fire",
                uniqueLocation,
                LocalDateTime.now(),
                "JUnit update test",
                4,
                20,
                "Severe"
        );

        dao.save(report);

        report.setPriority("Critical");
        report.setStatus("In Progress");
        report.setAssignedDepartment("Hospital");

        assertTrue(
                dao.update(report),
                "Existing report should be updated"
        );

        DisasterReport updated = dao.findAll().stream()
                .filter(r -> r.getDisasterId()
                        == report.getDisasterId())
                .findFirst()
                .orElse(null);

        assertNotNull(updated);
        assertEquals("Critical", updated.getPriority());
        assertEquals("In Progress", updated.getStatus());
        assertEquals(
                "Hospital",
                updated.getAssignedDepartment()
        );
    }

    @Test
    void updateNonexistentReportReturnsFalse()
            throws Exception {

        assertFalse(
                dao.update(new DisasterReport(
                        Integer.MAX_VALUE,
                        "Test",
                        "Nowhere",
                        LocalDateTime.now(),
                        "Nonexistent report",
                        1,
                        0,
                        "None"
                )),
                "Updating a nonexistent report should return false"
        );
    }
}
