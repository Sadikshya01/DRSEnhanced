-- DRS-Enhanced database setup
-- Run in MySQL Workbench. Set your own MySQL credentials in environment variables.
CREATE DATABASE IF NOT EXISTS drs_assessment3
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE drs_assessment3;

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(80) NOT NULL UNIQUE,
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('Public User','Disaster Response Officer') NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS disaster_reports (
  disaster_id INT AUTO_INCREMENT PRIMARY KEY,
  disaster_type VARCHAR(100) NOT NULL,
  location VARCHAR(255) NOT NULL,
  report_datetime DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  description TEXT NOT NULL,
  severity INT NOT NULL,
  people_affected INT NOT NULL DEFAULT 0,
  infrastructure_impact VARCHAR(255) NOT NULL,
  priority VARCHAR(30) NOT NULL DEFAULT 'Not Assessed',
  status VARCHAR(30) NOT NULL DEFAULT 'Reported',
  assigned_department VARCHAR(100) NOT NULL DEFAULT 'Not Assigned',
  CONSTRAINT chk_disaster_severity CHECK (severity BETWEEN 1 AND 5),
  CONSTRAINT chk_people_affected CHECK (people_affected >= 0)
);

CREATE TABLE IF NOT EXISTS emergency_shelters (
  shelter_id INT AUTO_INCREMENT PRIMARY KEY,
  shelter_name VARCHAR(150) NOT NULL,
  location VARCHAR(255) NOT NULL,
  capacity INT NOT NULL,
  occupants INT NOT NULL DEFAULT 0,
  availability ENUM('Available','Full') NOT NULL DEFAULT 'Available',
  contact_number VARCHAR(40),
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_shelter_capacity CHECK (capacity > 0),
  CONSTRAINT chk_shelter_occupants CHECK (occupants >= 0 AND occupants <= capacity)
);

-- Create users through the application's BCrypt hash helper or a secure admin setup.
-- Do not insert plaintext passwords into password_hash.
